--Write SQL commands that capture specific, usable data that can be used in your analysis.


SELECT c.State, COUNT(r.RMAID) AS NumberOfRMAs 
FROM RMA r 
INNER JOIN Customers c ON r.CustomerID = c.CustomerID 
GROUP BY c.State 
ORDER BY NumberOfRMAs DESC;


SELECT o.Description, COUNT(o.OrderID) AS NumberOfSales 
FROM Orders o 
GROUP BY o.Description 
ORDER BY NumberOfSales DESC;



SELECT o.Description, COUNT(r.RMAID) AS NumberOfReturns 
FROM RMA r 
INNER JOIN Orders o ON r.OrderID = o.OrderID 
INNER JOIN Customers c ON o.CustomerID = c.CustomerID 
WHERE c.State IN ('Washington', 'Oregon', 'Idaho', 'Montana') 
GROUP BY o.Description 
ORDER BY NumberOfReturns DESC;

SELECT o.Description, COUNT(*) AS NumberOfReturns 
FROM RMA r 
JOIN Orders o ON r.OrderID = o.OrderID 
JOIN Customers c ON o.CustomerID = c.CustomerID 
WHERE c.State IN ('Washington', 'Oregon', 'Idaho', 'Montana') 
GROUP BY o.Description 
ORDER BY NumberOfReturns DESC;
