--5.4 SIMPLE FUNCTIONS

/* The given SQL creates a Movie table, inserts some movies, and selects all movies.

Using the YEAR() and MONTH() functions, modify the SELECT statement to select movies that are released after 2017 or in November.

Run your solution and verify the result table shows just the movies with IDs 5, 6, 7, and 9. */

CREATE TABLE Movie (
  ID INT AUTO_INCREMENT,
  Title VARCHAR(100),
  Rating CHAR(5) CHECK (Rating IN ('G', 'PG', 'PG-13', 'R')),
  ReleaseDate DATE,
  PRIMARY KEY (ID)
);

INSERT INTO Movie (Title, Rating, ReleaseDate) VALUES
  ('Rogue One: A Star Wars Story', 'PG-13', '2016-12-16'),
  ('Casablanca', 'PG', '1943-01-23'),
  ('The Dark Knight', 'PG-13', '2008-07-18'),
  ('Hidden Figures', 'PG', '2017-01-06'),
  ('Toy Story', 'G', '1995-11-22'),
  ('Rocky', 'PG', '1976-11-21'),
  ('Crazy Rich Asians', 'PG-13', '2018-08-15'),
  ('Bridget Jones\'s Diary', 'PG-13', '2001-04-13'),
  ('Avengers: Endgame', 'PG-13', '2019-04-26');

-- Modify the SELECT statement:
SELECT *
FROM Movie
WHERE YEAR(ReleaseDate) > 2017 OR MONTH(ReleaseDate) = 11;

/*-------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------*/

--5.5 AGGREGATE FUNCTIONS
/* The given SQL creates a Song table and inserts some songs. The SELECT statement selects the genre and row count for each genre group.

Add a new column to the SELECT statement that uses MAX() to find the most recent release year for each genre. Then add a HAVING clause that selects only genre groups that have more than one row count.

Run your solution and verify country pop, R&B, and grunge genres, row counts, and most recent release years appear in the result table. */

CREATE TABLE Song (
  ID INT,
  Title VARCHAR(60),
  Artist VARCHAR(60),
  ReleaseYear INT,
  Genre VARCHAR(20),
  PRIMARY KEY (ID)
);

INSERT INTO Song VALUES
  (100, 'Hey Jude', 'Beatles', 1968, 'pop rock'),
  (200, 'You Belong With Me', 'Taylor Swift', 2008, 'country pop'),
  (300, 'You\'re Still the One', 'Shania Twain', 1998, 'country pop'),
  (400, 'Need You Now', 'Lady Antebellum', 2011, 'country pop'),
  (500, 'You\'ve Lost That Lovin\' Feeling', 'The Righteous Brothers', 1964, 'R&B'),
  (600, 'That\'s The Way Love Goes', 'Janet Jackson', 1993, 'R&B'),
  (700, 'Smells Like Teen Spirit', 'Nirvana', 1991, 'grunge'),
  (800, 'Even Flow', 'Pearl Jam', 1992, 'grunge'),
  (900, 'Black Hole Sun', 'Soundgarden', 1994, 'grunge');

-- Modify the SELECT statement
SELECT Genre, COUNT(*), MAX(ReleaseYear)
FROM Song
GROUP BY Genre
HAVING COUNT(*) > 1;

/*-------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------*/

--5.6 SUBQUERIES

/* The given SQL creates a Song table and inserts some songs. The first SELECT statement selects songs released after 1992. The second SELECT statement selects the release year for song with ID 800.

Create a third query that combines the two existing queries. The first SELECT should be the outer query, and the second SELECT should be the subquery. The ORDER BY clause should appear after the subquery.

Run your solution and verify the new query returns a result table with five rows, all with release years after 1992. */

CREATE TABLE Song (
  ID INT,
  Title VARCHAR(60),
  Artist VARCHAR(60),
  ReleaseYear INT,
  Genre VARCHAR(20),
  PRIMARY KEY (ID)
);

INSERT INTO Song VALUES
  (100, 'Hey Jude', 'Beatles', 1968, 'pop rock'),
  (200, 'You Belong With Me', 'Taylor Swift', 2008, 'country pop'),
  (300, 'You\'re Still the One', 'Shania Twain', 1998, 'country pop'),
  (400, 'Need You Now', 'Lady Antebellum', 2011, 'country pop'),
  (500, 'You\'ve Lost That Lovin\' Feeling', 'The Righteous Brothers', 1964, 'R&B'),
  (600, 'That\'s The Way Love Goes', 'Janet Jackson', 1993, 'R&B'),
  (700, 'Smells Like Teen Spirit', 'Nirvana', 1991, 'grunge'),
  (800, 'Even Flow', 'Pearl Jam', 1992, 'grunge'),
  (900, 'Black Hole Sun', 'Soundgarden', 1994, 'grunge');

SELECT *
FROM Song
WHERE ReleaseYear > 1992
ORDER BY ReleaseYear;

SELECT ReleaseYear
FROM Song 
WHERE ID = 800;

-- Write your SELECT statement here:
SELECT *
FROM Song
WHERE ReleaseYear >
  (SELECT ReleaseYear
   FROM Song 
   WHERE ID = 800)
ORDER BY ReleaseYear;

/*-------------------------------------------------------------------------------*/


/* The given SQL creates an Album and Song tables and inserts some albums and songs. Each song is associated with an album.

The SELECT statement selects all albums with three or more songs. Run the query and verify the result table shows just the albums Saturday Night Fever and 21.

Modify the GROUP BY clause to select albums with three or more songs by the same artist. Run the query and verify the result table shows just the album 21. */

CREATE TABLE Album (
  ID INT,
  Title VARCHAR(60),
  ReleaseYear INT,
  PRIMARY KEY (ID)
);

INSERT INTO Album VALUES
  (1, 'Saturday Night Fever', 1977),
  (2, 'Born in the U.S.A.', 1984),
  (3, 'Supernatural', 1999),
  (4, '21', 2011);

CREATE TABLE Song (
  ID INT,
  Title VARCHAR(60),
  Artist VARCHAR(60),
  AlbumID INT,
  PRIMARY KEY (ID),
  FOREIGN KEY (AlbumID) REFERENCES Album(ID)
);

INSERT INTO Song VALUES
  (100, 'Stayin\' Alive', 'Bee Gees', 1),
  (101, 'More Than a Woman', 'Bee Gees', 1),
  (102, 'If I Can\'t Have You', 'Yvonne Elliman', 1),
  (200, 'Dancing in the Dark', 'Bruce Springsteen', 2),
  (201, 'Glory Days', 'Bruce Springsteen', 2),
  (300, 'Smooth', 'Santana', 3),
  (400, 'Rolling in the Deep', 'Adele', 4),
  (401, 'Someone Like You', 'Adele', 4),
  (402, 'Set Fire to the Rain', 'Adele', 4),
  (403, 'Rumor Has It', 'Adele', 4);

SELECT *
FROM Album
WHERE EXISTS 
  (SELECT COUNT(*)
   FROM Song
   WHERE AlbumID = Album.ID 
   GROUP BY Artist
   HAVING COUNT(*) >=3);

/*-------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------*/

--5.7 COMPLEX QUERY EXAMPLES
/* Tables for the Zion Bookstore database are created and populated below. Run a query that joins the Sale, Customer, and Book tables: */

SELECT S.CustID, C.State, S.BookID, B.Title, S.Quantity, S.UnitPrice * S.Quantity 
FROM Sale S
INNER JOIN Customer C ON C.ID = S.CustID
INNER JOIN Book AS B ON B.ID = S.BookID;


CREATE TABLE Author (
  ID INT NOT NULL,
  FirstName VARCHAR(45) DEFAULT NULL,
  LastName VARCHAR(45) DEFAULT NULL,
  BirthDate DATE DEFAULT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO Author VALUES
(1,'Jennifer','McCoy', '1980-05-01'),
(2,'Yuto','Takahashi', '1973-12-04'),
(3,'Jose','Martinez', NULL),
(4,'Jasmine','Baxter', NULL),
(5,'Xiu','Tao', '1992-11-13'),
(6,'Ethan','Lonestar', '1965-02-15'),
(7,'Amar','Agarwal', NULL),
(8,'Emilia','Russo', '1999-08-03');

CREATE TABLE Book (
  ID INT NOT NULL,
  Title VARCHAR(200) DEFAULT NULL,
  Publisher VARCHAR(45) DEFAULT NULL,
  Category VARCHAR(20) CHECK (Category IN ('adventure','drama','fantasy','humor','romance','scifi')),
  Price DECIMAL(6,2) DEFAULT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO Book VALUES
(100,'The Black Box','Wright Pub','adventure',22.50),
(101,'Lost Time','Caster','scifi',19.99),
(102,'Which Way Home?','Light House','humor',8.99),
(103,'Grant Me Three Wishes','Caster','romance',10.75),
(104,'The Last Attempt','Longshot','scifi',15.99),
(105,'My Crazy Life','Light House','humor',9.67);


CREATE TABLE BookAuthor (
  AuthorID INT NOT NULL,
  BookID INT NOT NULL,
  PRIMARY KEY (AuthorID, BookID),
  FOREIGN KEY (AuthorID) REFERENCES Author (ID),
  FOREIGN KEY (BookID) REFERENCES Book (ID) 
);

INSERT INTO BookAuthor VALUES
(2,100),
(3,100),
(4,101),
(7,102),
(8,102),
(5,103),
(1,104),
(8,105);

CREATE TABLE Customer (
  ID INT NOT NULL,
  FirstName VARCHAR(45) DEFAULT NULL,
  LastName VARCHAR(45) DEFAULT NULL,
  Address VARCHAR(45) DEFAULT NULL,
  City VARCHAR(45) DEFAULT NULL,
  State CHAR(2) DEFAULT NULL,
  Zip INT DEFAULT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO Customer VALUES
(1,'Jill','Halloway','101 Main St','Boulder','CO',80301),
(2,'Mario','Androsa','4545 N 1st St','Tulsa','OK',74008),
(3,'Erica','MacCallum','999 S Fir Ct','Breckenridge','CO',80424),
(4,'John','Patrick de la Cruz','501 N Main','Albuquerque','NM',87109),
(5,'Anna','Green','600 S Main','Los Alamos','NM',87544),
(6,'Mo','Yan','211 W Lipan','Edmond','OK',73013),
(7,'Alexis','Brookhart','9000 S Greenwood','Englewood','CO',80110),
(8,'Hala','Nassar','840 N Pine St','Oklahoma City','OK',73008);


CREATE TABLE Sale (
  ID INT AUTO_INCREMENT NOT NULL,
  CustID INT DEFAULT NULL,
  BookID INT DEFAULT NULL,
  UnitPrice DECIMAL(6,2) DEFAULT NULL,
  Quantity INT DEFAULT NULL,
  Date DATETIME DEFAULT NULL,
  PRIMARY KEY (ID),
  FOREIGN KEY (CustID) REFERENCES Customer (ID),
  FOREIGN KEY (BookID) REFERENCES Book (ID)
);

INSERT INTO Sale (CustID, BookID, UnitPrice, Quantity, Date) VALUES 
(1,103,10.99,1,'2020-02-14 12:30:00'),
(2,104,15.5,2,'2020-02-15 14:15:00'),
(3,101,21.99,1,'2020-02-15 19:10:00'),
(6,104,16.00,2,'2020-02-15 19:25:00'),
(4,102,9.75,1,'2020-02-16 11:05:00'),
(4,105,9.50,1,'2020-02-16 11:05:00'),
(2,102,9.75,1,'2020-02-16 11:30:00'),
(5,104,16.0,1,'2020-02-16 15:25:00'),
(6,100,22.3,2,'2020-02-16 16:00:00'),
(2,103,10.99,1,'2020-02-17 12:30:00'),
(7,103,14.99,3,'2020-02-21 14:25:00'),
(7,104,16.00,1,'2020-02-21 14:25:00'),
(7,105,10.00,1,'2020-02-21 14:25:00'),
(1,101,15.20,1,'2020-02-22 13:15:00'),
(2,105,9.50,1,'2020-03-05 10:18:00'),
(1,100,22.5,1,'2021-02-01 09:15:00'),
(2,103,10.99,1,'2021-02-01 13:15:00'),
(2,101,15.60,1,'2021-02-01 13:15:00'),
(3,103,14.99,1,'2021-02-01 13:15:00');

   
-- Write your query here:
SELECT 
    S.CustID, 
    C.State, 
    S.BookID, 
    B.Title, 
    S.Quantity, 
    S.UnitPrice * S.Quantity AS TotalPrice 
FROM Sale S
INNER JOIN Customer C ON C.ID = S.CustID
INNER JOIN Book B ON B.ID = S.BookID;


/*-------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------*/

/*Use a modified query that sums the quantity and sales price for each book using the SUM() function. The GROUP BY clause groups the sums together for each book ID and state. The ORDER BY clause sorts the total sales in descending order. */

SELECT C.State, S.BookID, B.Title, SUM(S.Quantity) AS Quantity, SUM(S.UnitPrice * S.Quantity) AS TotalSales
FROM Sale S
INNER JOIN Customer C ON C.ID = S.CustID
INNER JOIN Book AS B ON B.ID = S.BookID 
GROUP BY C.State, S.BookID
ORDER BY TotalSales DESC;

CREATE TABLE Author (
  ID INT NOT NULL,
  FirstName VARCHAR(45) DEFAULT NULL,
  LastName VARCHAR(45) DEFAULT NULL,
  BirthDate DATE DEFAULT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO Author VALUES
(1,'Jennifer','McCoy', '1980-05-01'),
(2,'Yuto','Takahashi', '1973-12-04'),
(3,'Jose','Martinez', NULL),
(4,'Jasmine','Baxter', NULL),
(5,'Xiu','Tao', '1992-11-13'),
(6,'Ethan','Lonestar', '1965-02-15'),
(7,'Amar','Agarwal', NULL),
(8,'Emilia','Russo', '1999-08-03');

CREATE TABLE Book (
  ID INT NOT NULL,
  Title VARCHAR(200) DEFAULT NULL,
  Publisher VARCHAR(45) DEFAULT NULL,
  Category VARCHAR(20) CHECK (Category IN ('adventure','drama','fantasy','humor','romance','scifi')),
  Price DECIMAL(6,2) DEFAULT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO Book VALUES
(100,'The Black Box','Wright Pub','adventure',22.50),
(101,'Lost Time','Caster','scifi',19.99),
(102,'Which Way Home?','Light House','humor',8.99),
(103,'Grant Me Three Wishes','Caster','romance',10.75),
(104,'The Last Attempt','Longshot','scifi',15.99),
(105,'My Crazy Life','Light House','humor',9.67);


CREATE TABLE BookAuthor (
  AuthorID INT NOT NULL,
  BookID INT NOT NULL,
  PRIMARY KEY (AuthorID, BookID),
  FOREIGN KEY (AuthorID) REFERENCES Author (ID),
  FOREIGN KEY (BookID) REFERENCES Book (ID) 
);

INSERT INTO BookAuthor VALUES
(2,100),
(3,100),
(4,101),
(7,102),
(8,102),
(5,103),
(1,104),
(8,105);

CREATE TABLE Customer (
  ID INT NOT NULL,
  FirstName VARCHAR(45) DEFAULT NULL,
  LastName VARCHAR(45) DEFAULT NULL,
  Address VARCHAR(45) DEFAULT NULL,
  City VARCHAR(45) DEFAULT NULL,
  State CHAR(2) DEFAULT NULL,
  Zip INT DEFAULT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO Customer VALUES
(1,'Jill','Halloway','101 Main St','Boulder','CO',80301),
(2,'Mario','Androsa','4545 N 1st St','Tulsa','OK',74008),
(3,'Erica','MacCallum','999 S Fir Ct','Breckenridge','CO',80424),
(4,'John','Patrick de la Cruz','501 N Main','Albuquerque','NM',87109),
(5,'Anna','Green','600 S Main','Los Alamos','NM',87544),
(6,'Mo','Yan','211 W Lipan','Edmond','OK',73013),
(7,'Alexis','Brookhart','9000 S Greenwood','Englewood','CO',80110),
(8,'Hala','Nassar','840 N Pine St','Oklahoma City','OK',73008);


CREATE TABLE Sale (
  ID INT AUTO_INCREMENT NOT NULL,
  CustID INT DEFAULT NULL,
  BookID INT DEFAULT NULL,
  UnitPrice DECIMAL(6,2) DEFAULT NULL,
  Quantity INT DEFAULT NULL,
  Date DATETIME DEFAULT NULL,
  PRIMARY KEY (ID),
  FOREIGN KEY (CustID) REFERENCES Customer (ID),
  FOREIGN KEY (BookID) REFERENCES Book (ID)
);

INSERT INTO Sale (CustID, BookID, UnitPrice, Quantity, Date) VALUES 
(1,103,10.99,1,'2020-02-14 12:30:00'),
(2,104,15.5,2,'2020-02-15 14:15:00'),
(3,101,21.99,1,'2020-02-15 19:10:00'),
(6,104,16.00,2,'2020-02-15 19:25:00'),
(4,102,9.75,1,'2020-02-16 11:05:00'),
(4,105,9.50,1,'2020-02-16 11:05:00'),
(2,102,9.75,1,'2020-02-16 11:30:00'),
(5,104,16.0,1,'2020-02-16 15:25:00'),
(6,100,22.3,2,'2020-02-16 16:00:00'),
(2,103,10.99,1,'2020-02-17 12:30:00'),
(7,103,14.99,3,'2020-02-21 14:25:00'),
(7,104,16.00,1,'2020-02-21 14:25:00'),
(7,105,10.00,1,'2020-02-21 14:25:00'),
(1,101,15.20,1,'2020-02-22 13:15:00'),
(2,105,9.50,1,'2020-03-05 10:18:00'),
(1,100,22.5,1,'2021-02-01 09:15:00'),
(2,103,10.99,1,'2021-02-01 13:15:00'),
(2,101,15.60,1,'2021-02-01 13:15:00'),
(3,103,14.99,1,'2021-02-01 13:15:00');

   
-- Write your query here:
SELECT 
    C.State, 
    S.BookID, 
    B.Title, 
    SUM(S.Quantity) AS Quantity, 
    SUM(S.UnitPrice * S.Quantity) AS TotalSales
FROM Sale S
INNER JOIN Customer C ON C.ID = S.CustID
INNER JOIN Book B ON B.ID = S.BookID 
GROUP BY C.State, S.BookID, B.Title
ORDER BY TotalSales DESC;


/*-------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------*/

/* Add a WHERE clause to restrict the result table to sales from Colorado and Oklahoma only. Use the MONTH() and YEAR() functions to select only sales in month 2 and year 2020.*/

SELECT C.State, S.BookID, B.Title, SUM(S.Quantity) AS Quantity, SUM(S.UnitPrice * S.Quantity) AS TotalSales
FROM Sale S
INNER JOIN Customer C ON C.ID = S.CustID
INNER JOIN Book AS B ON B.ID = S.BookID 
WHERE (C.State = 'CO' OR C.State = 'OK') AND MONTH(S.Date) = 2 AND YEAR(S.Date) = 2020
GROUP BY C.State, S.BookID
ORDER BY TotalSales DESC; 

CREATE TABLE Author (
  ID INT NOT NULL,
  FirstName VARCHAR(45) DEFAULT NULL,
  LastName VARCHAR(45) DEFAULT NULL,
  BirthDate DATE DEFAULT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO Author VALUES
(1,'Jennifer','McCoy', '1980-05-01'),
(2,'Yuto','Takahashi', '1973-12-04'),
(3,'Jose','Martinez', NULL),
(4,'Jasmine','Baxter', NULL),
(5,'Xiu','Tao', '1992-11-13'),
(6,'Ethan','Lonestar', '1965-02-15'),
(7,'Amar','Agarwal', NULL),
(8,'Emilia','Russo', '1999-08-03');

CREATE TABLE Book (
  ID INT NOT NULL,
  Title VARCHAR(200) DEFAULT NULL,
  Publisher VARCHAR(45) DEFAULT NULL,
  Category VARCHAR(20) CHECK (Category IN ('adventure','drama','fantasy','humor','romance','scifi')),
  Price DECIMAL(6,2) DEFAULT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO Book VALUES
(100,'The Black Box','Wright Pub','adventure',22.50),
(101,'Lost Time','Caster','scifi',19.99),
(102,'Which Way Home?','Light House','humor',8.99),
(103,'Grant Me Three Wishes','Caster','romance',10.75),
(104,'The Last Attempt','Longshot','scifi',15.99),
(105,'My Crazy Life','Light House','humor',9.67);


CREATE TABLE BookAuthor (
  AuthorID INT NOT NULL,
  BookID INT NOT NULL,
  PRIMARY KEY (AuthorID, BookID),
  FOREIGN KEY (AuthorID) REFERENCES Author (ID),
  FOREIGN KEY (BookID) REFERENCES Book (ID) 
);

INSERT INTO BookAuthor VALUES
(2,100),
(3,100),
(4,101),
(7,102),
(8,102),
(5,103),
(1,104),
(8,105);

CREATE TABLE Customer (
  ID INT NOT NULL,
  FirstName VARCHAR(45) DEFAULT NULL,
  LastName VARCHAR(45) DEFAULT NULL,
  Address VARCHAR(45) DEFAULT NULL,
  City VARCHAR(45) DEFAULT NULL,
  State CHAR(2) DEFAULT NULL,
  Zip INT DEFAULT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO Customer VALUES
(1,'Jill','Halloway','101 Main St','Boulder','CO',80301),
(2,'Mario','Androsa','4545 N 1st St','Tulsa','OK',74008),
(3,'Erica','MacCallum','999 S Fir Ct','Breckenridge','CO',80424),
(4,'John','Patrick de la Cruz','501 N Main','Albuquerque','NM',87109),
(5,'Anna','Green','600 S Main','Los Alamos','NM',87544),
(6,'Mo','Yan','211 W Lipan','Edmond','OK',73013),
(7,'Alexis','Brookhart','9000 S Greenwood','Englewood','CO',80110),
(8,'Hala','Nassar','840 N Pine St','Oklahoma City','OK',73008);


CREATE TABLE Sale (
  ID INT AUTO_INCREMENT NOT NULL,
  CustID INT DEFAULT NULL,
  BookID INT DEFAULT NULL,
  UnitPrice DECIMAL(6,2) DEFAULT NULL,
  Quantity INT DEFAULT NULL,
  Date DATETIME DEFAULT NULL,
  PRIMARY KEY (ID),
  FOREIGN KEY (CustID) REFERENCES Customer (ID),
  FOREIGN KEY (BookID) REFERENCES Book (ID)
);

INSERT INTO Sale (CustID, BookID, UnitPrice, Quantity, Date) VALUES 
(1,103,10.99,1,'2020-02-14 12:30:00'),
(2,104,15.5,2,'2020-02-15 14:15:00'),
(3,101,21.99,1,'2020-02-15 19:10:00'),
(6,104,16.00,2,'2020-02-15 19:25:00'),
(4,102,9.75,1,'2020-02-16 11:05:00'),
(4,105,9.50,1,'2020-02-16 11:05:00'),
(2,102,9.75,1,'2020-02-16 11:30:00'),
(5,104,16.0,1,'2020-02-16 15:25:00'),
(6,100,22.3,2,'2020-02-16 16:00:00'),
(2,103,10.99,1,'2020-02-17 12:30:00'),
(7,103,14.99,3,'2020-02-21 14:25:00'),
(7,104,16.00,1,'2020-02-21 14:25:00'),
(7,105,10.00,1,'2020-02-21 14:25:00'),
(1,101,15.20,1,'2020-02-22 13:15:00'),
(2,105,9.50,1,'2020-03-05 10:18:00'),
(1,100,22.5,1,'2021-02-01 09:15:00'),
(2,103,10.99,1,'2021-02-01 13:15:00'),
(2,101,15.60,1,'2021-02-01 13:15:00'),
(3,103,14.99,1,'2021-02-01 13:15:00');

   
-- Write your query here:
SELECT C.State, S.BookID, B.Title, SUM(S.Quantity) AS Quantity, SUM(S.UnitPrice * S.Quantity) AS TotalSales
FROM Sale S
INNER JOIN Customer C ON C.ID = S.CustID
INNER JOIN Book AS B ON B.ID = S.BookID 
WHERE (C.State = 'CO' OR C.State = 'OK') AND MONTH(S.Date) = 2 AND YEAR(S.Date) = 2020
GROUP BY C.State, S.BookID, B.Title
ORDER BY TotalSales DESC;

/*-------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------*/

--SAME TABLE, DIFFERENT query
/* Modify the WHERE clause to use a subquery. The subquery uses a HAVING clause with COUNT() to select only book IDs that appear in one row of BookAuthor.

SELECT C.State, S.BookID, B.Title, SUM(S.Quantity) AS Quantity, SUM(S.UnitPrice * S.Quantity) AS TotalSales
FROM Sale S
INNER JOIN Customer C ON C.ID = S.CustID
INNER JOIN Book AS B ON B.ID = S.BookID 
WHERE (C.State = 'CO' OR C.State = 'OK') AND MONTH(S.Date) = 2 AND YEAR(S.Date) = 2020 AND B.ID IN 
   (SELECT BookID 
   FROM BookAuthor
   GROUP BY BookID
   HAVING COUNT(*) = 1)
GROUP BY C.State, S.BookID
ORDER BY TotalSales DESC; */

SELECT C.State, S.BookID, B.Title, SUM(S.Quantity) AS Quantity, SUM(S.UnitPrice * S.Quantity) AS TotalSales
FROM Sale S
INNER JOIN Customer C ON C.ID = S.CustID
INNER JOIN Book AS B ON B.ID = S.BookID 
WHERE (C.State = 'CO' OR C.State = 'OK') AND MONTH(S.Date) = 2 AND YEAR(S.Date) = 2020 AND B.ID IN 
   (SELECT BookID 
   FROM BookAuthor
   GROUP BY BookID
   HAVING COUNT(*) = 1)
GROUP BY C.State, S.BookID, B.Title
ORDER BY TotalSales DESC;

/*-------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------*/

--5.9 SPECIAL OPERATORS AND CLAUSES:

/* The given SQL creates a Movie table and inserts some movies. The SELECT statement selects all movies.

Modify the SELECT statement to select movies with the word 'star' somewhere in the title.

Run your solution and verify the result table shows just the movies Rogue One: A Star Wars Story, Star Trek and Stargate. */

CREATE TABLE Movie (
  ID INT AUTO_INCREMENT,
  Title VARCHAR(100),
  Rating CHAR(5) CHECK (Rating IN ('G', 'PG', 'PG-13', 'R')),
  ReleaseDate DATE,
  PRIMARY KEY (ID)
);

INSERT INTO Movie (Title, Rating, ReleaseDate) VALUES
  ('Rogue One: A Star Wars Story', 'PG-13', '2016-12-16'),
  ('Star Trek', 'PG-13', '2009-05-08'),
  ('The Dark Knight', 'PG-13', '2008-07-18'),
  ('Stargate', 'PG-13', '1994-10-28'),
  ('Avengers: Endgame', 'PG-13', '2019-04-26');

-- Modify the SELECT statement:
SELECT *
FROM Movie
WHERE Title LIKE '%star%';

/*-------------------------------------------------------------------------------*/

