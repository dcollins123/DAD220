USE Collins;


CREATE TABLE PartsMaintenance (
    VehicleID BIGINT(25),
    State CHAR(2),
    Repair VARCHAR(50),
    Reason VARCHAR(50),
    YEAR YEAR,
    Make VARCHAR(25),
    BodyType VARCHAR(50)
);

-- Loading the data
LOAD DATA INFILE '/home/codio/workspace/FleetMaintenanceRecords.csv'
INTO TABLE PartsMaintenance
FIELDS TERMINATED BY ',' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE '/home/codio/workspace/customers.csv' 
INTO TABLE Customers 
FIELDS TERMINATED BY ',' 
LINES TERMINATED BY '\r\n'; 
--1.A.i.

SELECT Repair, COUNT(Repair) as ReplacementCount
FROM PartsMaintenance
WHERE Repair NOT LIKE '%repair%' AND Repair NOT LIKE 'Repair'
GROUP BY Repair
ORDER BY ReplacementCount DESC;

/*-------------------------------------------------------------------------------*/

SELECT 'Southwest' as Region, COUNT(*) as ReplacementCount
FROM PartsMaintenance
WHERE State IN ('AZ', 'NM', 'TX', 'OK') AND Repair NOT LIKE 'repair' AND Repair NOT LIKE 'Repair'
GROUP BY Region;


SELECT 'Southeast' as Region, COUNT(*) as ReplacementCount
FROM PartsMaintenance
WHERE State IN ('AR', 'LA', 'MS', 'AL', 'GA', 'FL', 'KY', 'TN', 'SC', 'NC', 'VA', 'WV', 'DE', 'MD') AND Repair NOT LIKE 'repair' AND Repair NOT LIKE 'Repair'
GROUP BY Region;


SELECT 'Northeast' as Region, COUNT(*) as ReplacementCount
FROM PartsMaintenance
WHERE State IN ('PA', 'NJ', 'NY', 'CT', 'RI', 'MA', 'VT', 'NH', 'ME') AND Repair NOT LIKE 'repair' AND Repair NOT LIKE 'Repair'
GROUP BY Region;


SELECT 'Midwest' as Region, COUNT(*) as ReplacementCount
FROM PartsMaintenance
WHERE State IN ('ND', 'SD', 'KS', 'NE', 'MN', 'WI', 'IA', 'MO', 'MI', 'IN', 'IL', 'OH') AND Repair NOT LIKE 'repair' AND Repair NOT LIKE 'Repair'
GROUP BY Region;


SELECT 'West' as Region, COUNT(*) as ReplacementCount
FROM PartsMaintenance
WHERE State IN ('WA', 'ID', 'MT', 'OR', 'WY', 'CO', 'UT', 'NV', 'CA') AND Repair NOT LIKE 'repair' AND Repair NOT LIKE 'Repair'
GROUP BY Region;
